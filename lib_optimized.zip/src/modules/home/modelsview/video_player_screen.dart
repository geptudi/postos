
// Web-native HTML video player
import 'dart:html' as html;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';

class VideoPlayerScreen extends StatefulWidget {
  final String url;
  const VideoPlayerScreen({super.key, required this.url});

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late final String _viewId;
  late final html.VideoElement _video;

  @override
  void initState() {
    super.initState();
    _viewId = "video-${DateTime.now().millisecondsSinceEpoch}";
    _video = html.VideoElement()
      ..src = widget.url
      ..controls = true
      ..style.border = 'none'
      ..style.width = '100%'
      ..style.height = '100%';

    // ignore: undefined_prefixed_name
    ui.platformViewRegistry.registerViewFactory(
      _viewId,
      (int _) => _video,
    );
  }

  @override
  Widget build(BuildContext context) {
    return HtmlElementView(viewType: _viewId);
  }
}
